public class Modelo {
    int inteiro;
    double quebrado;
    String str;
    boolean bool;
    char c;
}
